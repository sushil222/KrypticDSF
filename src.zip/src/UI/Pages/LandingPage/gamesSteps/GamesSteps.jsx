import React from "react";
// import StepOne from "./AllSteps/Steps";
// import StepTwo from "./AllSteps/StepTwo";
// import StepThree from "./AllSteps/StepThree";
import Steps from "./AllSteps/Steps";

const GamesSteps = () => {
    return (
        <>
        <Steps/>
        </>
    )
}

export default GamesSteps;