
import Slider from "./section/Slider";
import Match from "./MatchContainer/Match";
import GamesSteps from './gamesSteps/GamesSteps';

function LandingPage() {
  return (
    <>
     
      <Slider />
      <Match />
      <GamesSteps />
    </>
  )
}

export default LandingPage;
