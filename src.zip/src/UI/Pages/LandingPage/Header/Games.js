const  Games =[
    {
        games:'DraftKings   ',
        sites:['NFL', 'NBA', 'NHL', 'MLB','WNBA', 'GOLF', 'SOCCER', 'CFL','CFB','LOL','MMA','NASCAR','TENNIS','CSGO'],
        path:'Draft_King'
    },
    {
        games:'Fanball',
        sites:['NFL'],
        path:'FAN_BALL'
    },
    {
        games:'FanDuel',
        sites:['NFL', 'NBA', 'NHL', 'MLB','WNBA', 'GOLF','LOL','MMA','NASCAR'],
        path:'FanDuel'
    },
    {
        games:'FantasyDraft',
       sites:['NFL', 'NBA', 'NHL', 'MLB', 'GOLF'],
       path:'Fantasy_Draft'
    },
    {
        games:'Yahoo',
        sites:['NFL', 'NBA', 'NHL', 'MLB', 'GOLF', 'SOCCER'],
        path:'Yahoo'
    },
    {
        games:'DraftKings Captain Mode',
        sites:['NFL', 'NBA', 'NHL', 'MLB','WNBA', 'SOCCER', 'LOL'],
        path:'Draft_Kings_captains_Mode'
    },
    {
        games:'FanDuel Single Game',
        sites:['NFL', 'NBA', 'NHL', 'MLB','LOL'],
        path:'FanDuel_single_Game'
    },
    {
        games:'DraftKings Tiers',
        sites:['NFL', 'NBA', 'NHL', 'MLB'],
        path:'Drafting_Tiers'
    }
]

export default Games